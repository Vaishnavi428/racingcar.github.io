var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["acd61838-c249-4e5b-8251-ca4109ab5706","fa7cc57b-c269-4f2c-bd83-f2ec6cb68698","763dc8dd-3fb1-48f0-8a34-2e22d3004213","8c365b23-c5c0-4e73-8b2f-8bbe515b33aa","279aea9a-4f54-44d4-8562-b60ad10ae4d5","ea05ea6b-502e-463a-86ef-63392836bbc0","70f96eaf-33bb-406a-9cef-c664b003a041","e791da42-584e-4a5f-a4db-2fb82bff04e5","279b97a6-566a-4d45-b883-1d81037d18d9","a15266a6-2eca-45ad-85c8-420e7c421c4e"],"propsByKey":{"acd61838-c249-4e5b-8251-ca4109ab5706":{"name":"screen3.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/acd61838-c249-4e5b-8251-ca4109ab5706.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"oqnFBF1lfJNMmsqeIP_7M9CaIiExtkm2","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/acd61838-c249-4e5b-8251-ca4109ab5706.png"},"fa7cc57b-c269-4f2c-bd83-f2ec6cb68698":{"name":"screen2.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/fa7cc57b-c269-4f2c-bd83-f2ec6cb68698.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"1M6wR3qEgiI9x_yfXOAaNJu.KRkBOu5s","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/fa7cc57b-c269-4f2c-bd83-f2ec6cb68698.png"},"763dc8dd-3fb1-48f0-8a34-2e22d3004213":{"name":"screen","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/763dc8dd-3fb1-48f0-8a34-2e22d3004213.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"W60FncO6WK1Hzd5bVmmt.pzrqRGQBJAd","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/763dc8dd-3fb1-48f0-8a34-2e22d3004213.png"},"8c365b23-c5c0-4e73-8b2f-8bbe515b33aa":{"name":"road.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/8c365b23-c5c0-4e73-8b2f-8bbe515b33aa.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"2bLQEBD89Z7ROJAQxRzA_bShyGGDFjuT","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/8c365b23-c5c0-4e73-8b2f-8bbe515b33aa.png"},"279aea9a-4f54-44d4-8562-b60ad10ae4d5":{"name":"car6.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/279aea9a-4f54-44d4-8562-b60ad10ae4d5.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"zVYtj.I0oKHVa1_1NIOyxW3jQZMGDeuf","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/279aea9a-4f54-44d4-8562-b60ad10ae4d5.png"},"ea05ea6b-502e-463a-86ef-63392836bbc0":{"name":"car4.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/ea05ea6b-502e-463a-86ef-63392836bbc0.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"EZQPsJZA5rQoL0MnOZ0H02Xi19CpGbrP","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/ea05ea6b-502e-463a-86ef-63392836bbc0.png"},"70f96eaf-33bb-406a-9cef-c664b003a041":{"name":"car3.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/70f96eaf-33bb-406a-9cef-c664b003a041.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"ErS2wb0skRgix9zwGwp20aFlC0PlmCCU","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/70f96eaf-33bb-406a-9cef-c664b003a041.png"},"e791da42-584e-4a5f-a4db-2fb82bff04e5":{"name":"car2.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/e791da42-584e-4a5f-a4db-2fb82bff04e5.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"01AfSDYKj0HTmHp24xK5O.TNSclPUyb.","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/e791da42-584e-4a5f-a4db-2fb82bff04e5.png"},"279b97a6-566a-4d45-b883-1d81037d18d9":{"name":"car5.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/279b97a6-566a-4d45-b883-1d81037d18d9.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"c7s.LcRNUUNh.KbrzofmqoQe_CpzpCQc","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/279b97a6-566a-4d45-b883-1d81037d18d9.png"},"a15266a6-2eca-45ad-85c8-420e7c421c4e":{"name":"car.png_1","sourceUrl":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/a15266a6-2eca-45ad-85c8-420e7c421c4e.png","frameSize":{"x":71,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"rI8SHQGzFDIt8cu5.Zkb.GxC0d1GdKU5","loadedFromSource":true,"saved":true,"sourceSize":{"x":71,"y":131},"rootRelativePath":"assets/v3/animations/B4tcc8bxcECdj9y45VVaxtHDK97LQdodMlJ1iH1Hypg/a15266a6-2eca-45ad-85c8-420e7c421c4e.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//create Road
var road = createSprite(205, 200);
road.setAnimation("road.png_1");
road.width = 1000;
road.height = 1000;
road.scale = 0.5;

//all random Cars and the main car
var car = createSprite(200, 300);
car.setAnimation("car.png_1");
car.scale = 0.5;

var car2 = createSprite(100, 200);
car2.setAnimation("car2.png_1");
car2.scale = 0.5;

var car3 = createSprite(325, 350);
car3.setAnimation("car3.png_1");
car3.scale = 0.5;

var car4 = createSprite(50, 30);
car4.setAnimation("car4.png_1");
car4.scale = 0.5;

var car5 = createSprite(350, 85);
car5.setAnimation("car5.png_1");
car5.scale = 0.5;

var car6 = createSprite(100, 10);
car6.setAnimation("car6.png_1");
car6.scale = 0.5;

var sprite = createSprite(200,200);
sprite.setAnimation("screen2.png_1");
sprite.scale =1;

//variables
var timer=0;
var timer2=0;
var time=0;
var gamestate=1;

function draw() {
  
  //keymovements
  if(keyDown("right")){
    car.x=car.x+10;
  }
    
  if(keyDown("left")){
    car.x=car.x-10;
  }
   
   //clashes
   if(car.isTouching(car2)||car.isTouching(car3)||car.isTouching(car4)||car.isTouching(car5)||car.isTouching(car6)) {
     var screen = createSprite(200,200);
     screen.setAnimation("screen");
   }
   
   
   //to make sure that  cars are not overlapping others
   if(car2.isTouching(car3)||car2.isTouching(car4)||car2.isTouching(car5)||car2.isTouching(car6)){
     car2.y = randomNumber(0,0);
     car2.x = randomNumber(400,0);
   }
   
   if(car3.isTouching(car4)||car3.isTouching(car5)||car3.isTouching(car6)){
     car3.y = randomNumber(0,0);
     car3.x = randomNumber(400,0);
   }
   
   if(car4.isTouching(car5)||car4.isTouching(car6)){
     car4.y = randomNumber(0,0);
     car4.x = randomNumber(400,0);
   }
   
   if(car5.isTouching(car6)){
     car5.y = randomNumber(0,0);
     car5.x = randomNumber(400,0);
   }
   
   if(car2.y > 405){
     car2.y =randomNumber(0,0);
     car2.x =randomNumber(400,0);
   }
   
   if(car3.y > 405){
     car3.y =randomNumber(0,0);
     car3.x =randomNumber(400,0);
   }
   
   if(car4.y > 405){
     car4.y =randomNumber(0,0);
     car4.x =randomNumber(400,0);
   }
   
   if(car5.y > 405){
     car5.y =randomNumber(0,0);
     car5.x =randomNumber(400,0);
   }
   
   if(car6.y > 405){
     car6.y =randomNumber(0,0);
     car6.x =randomNumber(400,0);
   }
   
   if(car.x > 405){
     car.x = 0;
   }
   
   if(car.x < -5){
     car.x = 400;
   }
   
   if(timer > 44){
     var screen3 = createSprite(200,200);
     screen3.setAnimation("screen3.png_1");
     screen3.scale = 1;
   }
  drawSprites();
  
  if(keyDown("space")) {
    timer2 = World.seconds;
    gamestate = 2;
   }
  if(gamestate===2){
    timer=World.seconds-timer2;
    car2.velocityY=8;
    car3.velocityY=8;
    car4.velocityY=8;
    car5.velocityY=8;
    car6.velocityY=8;
    sprite.visible=false;
  
   //timer text
   fill("white");
   textSize(20);
    text("Time: " + timer, 10, 10, 80, 20);
   textFont("Courier New");
  }
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
